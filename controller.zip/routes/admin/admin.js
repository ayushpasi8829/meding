const express = require("express");
const doctorController = require("../../controller/admin/adminController");
const { verifyToken, isDoctor, isAdmin, isUser } = require("../../middleware/authMiddleware");

const router = express.Router();

router.post("/doctors", verifyToken, isAdmin, doctorController.createDoctor);
router.get("/doctors", verifyToken, isAdmin, doctorController.getDoctors);
router.put("/doctors/:id", verifyToken, isAdmin, doctorController.updateDoctor);
router.delete("/doctors/:id", verifyToken, isAdmin, doctorController.deleteDoctor);

router.post("/users", verifyToken, isAdmin, doctorController.createUser); 
router.get("/users", verifyToken, isAdmin, doctorController.userList);   
router.put("/users/:id", verifyToken, isAdmin, doctorController.updateUser); 
router.delete("/users/:id", verifyToken, isAdmin, doctorController.deleteUser)


router.get("/get/session-stats", verifyToken, isAdmin, doctorController.SessionStats);
router.post("/send", doctorController.sendWhatsAppMessage);

module.exports = router;

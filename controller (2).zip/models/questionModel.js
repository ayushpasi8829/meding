const mongoose = require("mongoose");

const questionSchema = new mongoose.Schema({
  question: { type: String, required: true },
  options: {
    type: [String],
    default: ["Almost Always", "Often", "Sometimes","Rarely"],
  },
});

module.exports = mongoose.model("QuizQuestion", questionSchema);
